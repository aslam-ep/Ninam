package com.example.aslam.ninam;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ChangePasswordF extends AppCompatActivity {
    EditText et1,et2;
    Button b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle("Forget Password");
        setContentView(R.layout.activity_change_password_f);
        try {

            if (Build.VERSION.SDK_INT > 9) {
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
            }
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "error", Toast.LENGTH_SHORT).show();
        }

        //var
        et1=findViewById(R.id.editText19);
        et2=findViewById(R.id.editText18);
        b=findViewById(R.id.button13);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pass,conf,lid,ip;
                pass=et1.getText().toString();
                conf=et2.getText().toString();
                lid=getIntent().getStringExtra("lid");
                SharedPreferences sp= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                ip=sp.getString("ip","");
                String url = "http://"+ip+"/ninam/ChangePassword.php";
                if(pass.equals(conf)){
                    List<NameValuePair> list = new ArrayList<>();
                    list.add(new BasicNameValuePair("id", lid));
                    list.add(new BasicNameValuePair("pass", pass));
                    JSONParser jn = new JSONParser();
                    JSONObject jsonObject = jn.makeHttpRequest(url,"GET",list);
                    String res1 = null;
                    try {
                        res1 = jsonObject.getString("status");
                        if(res1.equalsIgnoreCase("1")) {
                            Toast.makeText(getApplicationContext(), "Password Changed", Toast.LENGTH_SHORT).show();
                        } else  {
                            Toast.makeText(getApplicationContext(), "Can't Change Password", Toast.LENGTH_SHORT).show();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }else{
                    et2.setError("Password miss match");
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        Intent i=new Intent(getApplicationContext(),ForgetPassword.class);
        startActivity(i);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
