package com.example.aslam.ninam;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

//DEVELOPED BY Hector(aslamepnd7@gmail.com)

public class Hospital extends AppCompatActivity {
    String ip,url,disc,lid;
    ListView l;
    SharedPreferences sp;
    String [] name,phone,email,d;
    ArrayList<DataModel> dataModels;
    int STORAGE_PERMISSION_CODE=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital);

        //Initialize
        l=findViewById(R.id.listview2);
        sp= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        ip=sp.getString("ip","");
        lid=sp.getString("lid","");
        url = "http://"+ip+"/ninam/viewHospital.php";

        setTitle("Hospitals");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //requesting permission
        if (ContextCompat.checkSelfPermission(Hospital.this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {

        } else {
            requestStoragePermission();
        }

        //json parsing data
        try {
            List<NameValuePair> list = new ArrayList<>();
            list.add(new BasicNameValuePair("lid", lid));
            JSONParser jn = new JSONParser();
            JSONObject jsonObject = jn.makeHttpRequest(url, "GET", list);
            String res = jsonObject.getString("status");
            if (res.equalsIgnoreCase("1")) {
                JSONArray ja;
                ja = jsonObject.getJSONArray("data");
                name = new String[ja.length()];
                phone = new String[ja.length()];
                email = new String[ja.length()];
                d = new String[ja.length()];
                dataModels= new ArrayList<>();
                for (int i = 0; i < ja.length(); i++) {
                    JSONObject jo = ja.getJSONObject(i);
                    name[i] = jo.getString("name");
                    email[i] = jo.getString("email");
                    phone[i] = jo.getString("phone");
                    d[i] = name[i] + "\t" + email[i]+"\t"+phone[i];
                    Log.d("Date===",d[i] );
                    dataModels.add(new DataModel(name[i], email[i], "",phone[i]));
                    CoustomAdapter add;
                    add = new CoustomAdapter(dataModels, getApplicationContext());
                    l.setAdapter(add);
                }
            } else if (res.equalsIgnoreCase("2")) {
                Toast.makeText(getApplicationContext(),"No Hospitals",Toast.LENGTH_SHORT).show();
            }
        } catch (Exception ex) {
            Log.d("ER===",ex.toString());
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
    private void requestStoragePermission() {
        ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CALL_PHONE}, STORAGE_PERMISSION_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == STORAGE_PERMISSION_CODE)  {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

            } else {
                Toast.makeText(this, "Permission DENIED", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
