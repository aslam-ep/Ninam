package com.example.aslam.ninam;

import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationListener;
import android.os.Build;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class CreateAccount extends AppCompatActivity {

    Button b;
    EditText t1,t2,t3,t4,t5;
    String name,email,pass,conf,phone,gender,bg,dis,url;
    RadioGroup rg;
    RadioButton g;
    Spinner sp1,sp2;
    String blood[]={"A+ve","A-ve","B+ve","B-ve","O+ve","O-ve","AB+ve","AB-ve"};
    String disc[]={"Alappuzha","Ernakulam","Idukki","Kannur","Kasaragod","Kollam","Kottayam","Kozhikode","Malappuram","Palakkad","Pathanamthitta","Thiruvananthapuram","Thrissur","Wayanad"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle("Join With Us");
        setContentView(R.layout.activity_create_account);
        try {
            if (Build.VERSION.SDK_INT > 9) {
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
            }
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "error", Toast.LENGTH_SHORT).show();
        }
        t1=findViewById(R.id.editText3);
        t2=findViewById(R.id.editText4);
        t3=findViewById(R.id.editText5);
        t4=findViewById(R.id.editText7);
        t5=findViewById(R.id.editText8);
        b=findViewById(R.id.button10);
        rg=findViewById(R.id.rg);
        sp1=(Spinner) findViewById(R.id.spinner);
        sp2=(Spinner) findViewById(R.id.spinner2);
        ArrayAdapter<String> add = new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line, blood);
        sp1.setAdapter(add);
        ArrayAdapter<String> add1 = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, disc);
        sp2.setAdapter(add1);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                name=t1.getText().toString();
                email=t2.getText().toString();
                phone=t3.getText().toString();
                pass=t4.getText().toString();
                conf=t5.getText().toString();
                int selectedId = rg.getCheckedRadioButtonId();
                // find the radiobutton by returned id
                g = (RadioButton) findViewById(selectedId);
                gender=g.getText().toString();
                bg=sp1.getSelectedItem().toString();
                dis=sp2.getSelectedItem().toString();
                SharedPreferences sp= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                String ip=sp.getString("ip","");
                url = "http://"+ip+"/ninam/createAccount.php";
                if(pass.equalsIgnoreCase(conf)) {

                    if (validate()==1) {
                        //valid();
                        try {
                            List<NameValuePair> list = new ArrayList<>();
                            list.add(new BasicNameValuePair("name", name));
                            list.add(new BasicNameValuePair("email", email));
                            list.add(new BasicNameValuePair("phone", phone));
                            list.add(new BasicNameValuePair("gender", gender));
                            list.add(new BasicNameValuePair("bg", bg));
                            list.add(new BasicNameValuePair("disc", dis));
                            list.add(new BasicNameValuePair("pass", pass));
                            JSONParser jn = new JSONParser();
                            JSONObject jsonObject = jn.makeHttpRequest(url,"GET",list);
                            String res = jsonObject.getString("status");
                            if(res.equalsIgnoreCase("1")) {
                                finish();
                                Intent i = new Intent(getApplicationContext(),OTP_create_account.class);
                                i.putExtra("id",jsonObject.getString("lid"));
                                i.putExtra("email", email);
                                startActivity(i);
                            }
                            else
                            {
                                Toast.makeText(getApplicationContext(), "Account Creation Failed", Toast.LENGTH_SHORT).show();
                            }
                        }
                        catch (Exception ex)
                        {
                            Toast.makeText(getApplicationContext(), ex.toString(), Toast.LENGTH_SHORT).show();
                            Log.d("ERRRR",ex.toString());
                        }
                    }
                }
                else {
                    Toast.makeText(getApplicationContext(), "Password Mismatch", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    /*private void valid() {
        t1.setError("");
        t2.setError("");
        t3.setError("");
        t4.setError("");
        t5.setError("");
    }*/

    private int validate() {
        if(name.isEmpty()){
            t1.setError("Name required");
            return 0;
        }
        else if(email.isEmpty()){
            t2.setError("Email required");
            return 0;
        }
        else if(phone.isEmpty()){
            t4.setError("Password required");
            return 0;
        }else if(pass.length()<6){
            t4.setError("Password should be 6 or more");
            return 0;
        }
        else if(phone.isEmpty()){
            t3.setError("Phone number required");
            return 0;
        }
        else if(conf.isEmpty()){
            t5.setError("Confirm password required");
            return 0;
        }else if(!pass.equals(conf)){
            t5.setError("Password mismatch");
            return 0;
        }
        else if(phone.length()!=10){
            t3.setError("Phone must be 10 numbers");
            return 0;
        } else {
            return 1;
        }
    }
}
