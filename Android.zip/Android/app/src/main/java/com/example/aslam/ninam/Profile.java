package com.example.aslam.ninam;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

//DEVELOPED BY Hector(aslamepnd7@gmail.com)

public class Profile extends AppCompatActivity {
    String lid,n,e,p,b,d,g;
    TextView name,email,phone,blood,disc,gender;
    Button editprofile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Profile");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.activity_profile);
        editprofile=findViewById(R.id.textView19);
        name=findViewById(R.id.textView10);
        email=findViewById(R.id.textView11);
        phone=findViewById(R.id.textView12);
        disc=findViewById(R.id.textView18);
        gender=findViewById(R.id.textView13);
        blood=findViewById(R.id.textView14);

        try {
            if (Build.VERSION.SDK_INT > 9) {
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
            }
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "error", Toast.LENGTH_SHORT).show();
        }

        try {
            SharedPreferences sp= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
            String ip=sp.getString("ip","");
            lid=sp.getString("lid","");
            String url = "http://"+ip+"/ninam/Profile.php";
            List<NameValuePair> list = new ArrayList<>();
            list.add(new BasicNameValuePair("lid", lid));
            JSONParser jn = new JSONParser();
            JSONObject jsonObject = jn.makeHttpRequest(url,"GET",list);
            String res = jsonObject.getString("status");
            if(res.equalsIgnoreCase("1")) {
                n=jsonObject.getString("name");
                name.setText(n);
                e=jsonObject.getString("email");
                email.setText(e);
                p=jsonObject.getString("phone");
                phone.setText(p);
                d=jsonObject.getString("disc");
                disc.setText(d);
                g=jsonObject.getString("gender");
                gender.setText(g);
                b=jsonObject.getString("bg");
                blood.setText(b);
            }
            else
            {
                Toast.makeText(getApplicationContext(), "Network Error", Toast.LENGTH_SHORT).show();
            }
        }
        catch (Exception ex)
        {
            Toast.makeText(getApplicationContext(), ex.toString(), Toast.LENGTH_SHORT).show();
            Log.d("ERRRR",ex.toString());
        }
        editprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),EditProfile.class);
                i.putExtra("lid",lid);
                i.putExtra("name",n);
                i.putExtra("phone",p);
                i.putExtra("gender",g);
                i.putExtra("bg",b);
                i.putExtra("disc",d);
                startActivity(i);
                finish();
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
