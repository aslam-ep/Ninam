package com.example.aslam.ninam;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

//DEVELOPED BY Hector(aslamepnd7@gmail.com)

public class ForgetPassword extends AppCompatActivity {
    EditText et1,et2;
    TextView t1,t2;
    String email;
    String OTP;
    String lid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle("Forget Password");
        setContentView(R.layout.activity_forget_password);
        try {
            if (Build.VERSION.SDK_INT > 9) {
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
            }
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "error", Toast.LENGTH_SHORT).show();
        }
        et1 =findViewById(R.id.editText16);
        et2 =findViewById(R.id.editText17);
        t1 =findViewById(R.id.textView14);
        t2 =findViewById(R.id.textView15);
        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String numbers = "0123456789";
                Random rndm_method = new Random();
                char[] otp = new char[4];
                for (int i = 0; i < 4; i++)
                {
                    otp[i] = numbers.charAt(rndm_method.nextInt(numbers.length()));
                }
                OTP= String.valueOf(otp);
                email=et1.getText().toString();
                if(!email.equals("")){
                    SharedPreferences sp= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                    String ip=sp.getString("ip","");
                    String url = "http://"+ip+"/ninam/getLid.php";
                    List<NameValuePair> list = new ArrayList<>();
                    list.add(new BasicNameValuePair("email", email));
                    list.add(new BasicNameValuePair("OTP", OTP));
                    JSONParser jn = new JSONParser();
                    JSONObject jsonObject = jn.makeHttpRequest(url,"GET",list);
                    String res = null;
                    try {
                        res = jsonObject.getString("status");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    if(res.equalsIgnoreCase("1")) {
                        try {
                            lid=jsonObject.getString("lid");
                            Toast.makeText(getApplicationContext(), "OTP SENDED", Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Email id not valid", Toast.LENGTH_SHORT).show();
                    }
                }else {
                    et1.setError("Enter Email");
                }
            }
        });
        t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(et2.getText().toString().equals(OTP)){
                    finish();
                    Intent i = new Intent(getApplicationContext(),ChangePasswordF.class);
                    i.putExtra("lid",lid);
                    startActivity(i);
                }else {
                    Toast.makeText(getApplicationContext(),"OTP Not Verfied",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
