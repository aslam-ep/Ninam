package com.example.aslam.ninam;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

//DEVELOPED BY Hector(aslamepnd7@gmail.com)

public class EditProfile extends AppCompatActivity {
    Button b;
    String lid,name,phone,gender,bg,disc;
    EditText et1,et2;
    RadioButton rb1,rb2,g;
    RadioGroup rg;
    Spinner sp1,sp2;
    String blood[]={"A+ve","A-ve","B+ve","B-ve","O+ve","O-ve","AB+ve","AB-ve"};
    String disc1[]={"Alappuzha","Ernakulam","Idukki","Kannur","Kasaragod","Kollam","Kottayam","Kozhikode","Malappuram","Palakkad","Pathanamthitta","Thiruvananthapuram","Thrissur","Wayanad"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle("Edit Profile");
        setContentView(R.layout.activity_edit_profile);
        try {

            if (Build.VERSION.SDK_INT > 9) {
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
            }
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "error", Toast.LENGTH_SHORT).show();
        }

        lid=getIntent().getStringExtra("lid");
        name=getIntent().getStringExtra("name");
        phone=getIntent().getStringExtra("phone");
        gender=getIntent().getStringExtra("gender");
        bg=getIntent().getStringExtra("bg");
        disc=getIntent().getStringExtra("disc");

        et1=findViewById(R.id.editText12);
        et2=findViewById(R.id.editText20);

        rb1=findViewById(R.id.radioButton6);
        rb2=findViewById(R.id.radioButton7);

        sp1=findViewById(R.id.spinner5);
        sp2=findViewById(R.id.spinner6);

        b=findViewById(R.id.button14);

        rg=findViewById(R.id.rg22);
        ArrayAdapter<String> add = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_dropdown_item_1line, blood);
        sp1.setAdapter(add);
        ArrayAdapter<String> add1 = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_dropdown_item_1line, disc1);
        sp2.setAdapter(add1);

        et1.setText(name);
        et2.setText(phone);
        if (gender.equals("Male")) {
            rb1.setChecked(true);
        } else {
            rb2.setChecked(true);
        }

        int s=add.getPosition(bg);
        sp1.setSelection(s);
        int s2=add1.getPosition(disc);
        sp2.setSelection(s2);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                name=et1.getText().toString();
                phone=et2.getText().toString();
                int selectedId = rg.getCheckedRadioButtonId();
                // find the radiobutton by returned id
                g = findViewById(selectedId);
                gender=g.getText().toString();
                bg=sp1.getSelectedItem().toString();
                disc=sp2.getSelectedItem().toString();
                SharedPreferences sp= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                String ip=sp.getString("ip","");
                String url = "http://"+ip+"/ninam/EditProfile.php";
                if(valid()){
                    try {
                        List<NameValuePair> list = new ArrayList<>();
                        list.add(new BasicNameValuePair("name", name));
                        list.add(new BasicNameValuePair("lid", lid));
                        list.add(new BasicNameValuePair("phone", phone));
                        list.add(new BasicNameValuePair("gender", gender));
                        list.add(new BasicNameValuePair("bg", bg));
                        list.add(new BasicNameValuePair("disc", disc));
                        JSONParser jn = new JSONParser();
                        JSONObject jsonObject = jn.makeHttpRequest(url,"GET",list);
                        String res = jsonObject.getString("status");
                        if(res.equalsIgnoreCase("1")) {
                            Toast.makeText(getApplicationContext(), "Profile Edited", Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(getApplicationContext(),Profile.class);
                            startActivity(i);
                            finish();
                        } else {
                            Toast.makeText(getApplicationContext(), "Profile Can't Edit", Toast.LENGTH_SHORT).show();
                        }
                    }
                    catch (Exception ex)
                    {
                        Toast.makeText(getApplicationContext(), ex.toString(), Toast.LENGTH_SHORT).show();
                        Log.d("ERRRR",ex.toString());
                    }
                }

            }
        });
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        Intent i=new Intent(getApplicationContext(),Profile.class);
        startActivity(i);
        finish();
        return true;
    }

    private boolean valid() {
        if(name.isEmpty()){
            et1.setError("Name required");
            return false;
        }
        else if(phone.isEmpty()){
            et2.setError("Phone required");
            return false;
        } else {
            return true;
        }
    }
}
