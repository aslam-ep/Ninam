package com.example.aslam.ninam;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

//DEVELOPED BY Hector(aslamepnd7@gmail.com)

public class Login extends AppCompatActivity {
    EditText et1,et2;
    Button b;
    TextView t1,t2;
    SharedPreferences sp;
    String ip,email,pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_login);

            try {
                if (Build.VERSION.SDK_INT > 9) {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                }
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "error", Toast.LENGTH_SHORT).show();
            }

        sp= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String lid=sp.getString("lid","");
        if(!lid.equals("0")){
            Intent i=new Intent(getApplicationContext(),MainActivity.class);
            startActivity(i);
            finish();
        }
        et1=findViewById(R.id.editText);
        et2=findViewById(R.id.editText2);
        b=findViewById(R.id.button9);
        t1=findViewById(R.id.textView9);
        t2=findViewById(R.id.textView25);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                email=et1.getText().toString();
                pass=et2.getText().toString();
                if(email.equals("")){
                    et1.setError("Email Required");
                }else if(pass.equals("")){
                    et2.setError("Password Required");
                }else {
                    ip=sp.getString("ip","");
                    String url = "http://"+ip+"/ninam/Login.php";

                    List<NameValuePair> list = new ArrayList<>();
                    list.add(new BasicNameValuePair("pass", pass));
                    list.add(new BasicNameValuePair("email", email));
                    JSONParser jn = new JSONParser();
                    JSONObject jsonObject = jn.makeHttpRequest(url,"GET",list);
                    String res = null;
                    String lid = null;
                    try {
                        res = jsonObject.getString("status");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    if(res.equalsIgnoreCase("1")) {
                        try {
                            lid = jsonObject.getString("lid");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        SharedPreferences sp2 = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                        SharedPreferences.Editor edd2 = sp2.edit();
                        edd2.putString("lid", lid);
                        edd2.commit();

                        Intent i = new Intent(Login.this, MainActivity.class);
                        startActivity(i);
                        finish();
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Invalid Username or Password", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(Login.this,ForgetPassword.class);
                startActivity(i);
            }
        });
        t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(Login.this,CreateAccount.class);
                startActivity(i);
            }
        });
    }
}
