package com.example.aslam.ninam;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

//DEVELOPED BY Hector(aslamepnd7@gmail.com)

public class ispet extends AppCompatActivity {
    Button b;
    EditText et;
    SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ispet);
        b=findViewById(R.id.button15);
        et=findViewById(R.id.editText21);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String ip=et.getText().toString();
                SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                SharedPreferences.Editor edd = sp.edit();
                edd.putString("ip", ip);
                edd.commit();
                Intent i = new Intent(getApplicationContext(),Login.class);
                startActivity(i);
                finish();
            }
        });
    }

}
