package com.example.aslam.ninam;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ChangePassword extends AppCompatActivity {
    EditText t1,t2,t3;
    Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        setTitle("Change Password");

        setContentView(R.layout.activity_change_password);
        try {

            if (Build.VERSION.SDK_INT > 9) {
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
            }
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "error", Toast.LENGTH_SHORT).show();
        }
        t1= findViewById(R.id.editText6);
        t2= findViewById(R.id.editText14);
        t3= findViewById(R.id.editText15);
        b= findViewById(R.id.button12);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url,pass,conf,current;
                current=t1.getText().toString();
                pass=t2.getText().toString();
                conf=t3.getText().toString();
                if(current.equals("")){
                    t1.setError("Current Password Required");
                }else if(pass.equals("")){
                    t2.setError("Password Required");
                }else if(conf.equals("")){
                    t3.setError("Confirm Password Required");
                }else if(!pass.equals(conf)){
                    t3.setError("Password didn't match");
                }else{
                    SharedPreferences sp= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                    String ip=sp.getString("ip","");
                    String lid=sp.getString("lid","");
                    url = "http://"+ip+"/ninam/ChangePassword2.php";

                    try {
                        List<NameValuePair> list = new ArrayList<>();
                        list.add(new BasicNameValuePair("current",current));
                        list.add(new BasicNameValuePair("lid", lid));
                        list.add(new BasicNameValuePair("pass", pass));
                        JSONParser jn = new JSONParser();
                        JSONObject jsonObject = jn.makeHttpRequest(url,"GET",list);
                        String res = jsonObject.getString("status");
                        if(res.equalsIgnoreCase("0")) {
                            Toast.makeText(getApplicationContext(), "Password Update Failed", Toast.LENGTH_SHORT).show();
                        } else if(res.equals("1")) {
                            Toast.makeText(getApplicationContext(), "Current Password Did'nt Match", Toast.LENGTH_SHORT).show();
                        } else{
                            Toast.makeText(getApplicationContext(), "Password Updated Successfully" , Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }
                    catch (Exception ex)
                    {
                        Toast.makeText(getApplicationContext(), ex.toString(), Toast.LENGTH_SHORT).show();
                        Log.d("ERRRR",ex.toString());
                    }
                }

            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
